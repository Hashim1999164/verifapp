//
//  verifapp.h
//  verifapp
//
//  Created by Hashim Khan on 10/12/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for verifapp.
FOUNDATION_EXPORT double verifappVersionNumber;

//! Project version string for verifapp.
FOUNDATION_EXPORT const unsigned char verifappVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <verifapp/PublicHeader.h>


